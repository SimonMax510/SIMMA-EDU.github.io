"""
Bike Monitor — Web-Adminpanel
Login-geschützte Oberfläche zum Bearbeiten der config.json.
"""
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import check_password_hash
from pathlib import Path
from functools import wraps
import json
import os
import secrets

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / "config.json"
USERS_PATH = BASE_DIR / "webapp" / "users.json"
SECRET_PATH = BASE_DIR / ".secret_key"

app = Flask(__name__)


def get_secret_key() -> str:
    """Lädt oder erzeugt einen persistenten Secret-Key für Session-Cookies."""
    env = os.environ.get("BIKE_MONITOR_SECRET")
    if env:
        return env
    if SECRET_PATH.exists():
        return SECRET_PATH.read_text().strip()
    key = secrets.token_hex(32)
    SECRET_PATH.write_text(key)
    SECRET_PATH.chmod(0o600)
    return key


app.secret_key = get_secret_key()


# ---------- Config-Handling ----------

def default_config() -> dict:
    return {
        "display": {
            "url": "https://example.com",
            "refresh_interval_sec": 30,
            "fullscreen": True,
        },
        "api": {
            "backend_url": "https://backend.example.com/ingest",
            "send_interval_ms": 1000,
            "auth_token": "",
            "method": "POST",
            "timeout_sec": 5,
        },
        "bikes": [
            {"id": i, "name": f"Fahrrad {i}", "sensor_pin": pin,
             "wheel_circumference_m": 2.1, "enabled": True}
            for i, pin in enumerate([17, 18, 22, 23], start=1)
        ],
    }


def load_config() -> dict:
    if not CONFIG_PATH.exists():
        cfg = default_config()
        save_config(cfg)
        return cfg
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_config(config: dict) -> None:
    """Schreibt atomar (über temp file + rename), damit der Worker nie eine halb geschriebene Datei liest."""
    tmp = CONFIG_PATH.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    os.replace(tmp, CONFIG_PATH)


def load_users() -> dict:
    if not USERS_PATH.exists():
        return {}
    with open(USERS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


# ---------- Auth ----------

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated


@app.route("/login", methods=["GET", "POST"])
def login():
    if "user" in session:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        users = load_users()
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if username in users and check_password_hash(users[username], password):
            session["user"] = username
            session.permanent = True
            return redirect(url_for("dashboard"))
        flash("Ungültiger Benutzername oder Passwort.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("login"))


# ---------- Pages ----------

@app.route("/")
@login_required
def dashboard():
    return render_template("dashboard.html", config=load_config(), user=session["user"])


# ---------- API ----------

def _validate_and_normalize(data: dict) -> dict:
    """Strikte Validierung der eingehenden Config — wirft ValueError bei Problemen."""
    if not isinstance(data, dict):
        raise ValueError("Body muss ein Objekt sein")

    d = data.get("display", {})
    a = data.get("api", {})
    bikes = data.get("bikes", [])

    if not isinstance(bikes, list) or not bikes:
        raise ValueError("Mindestens ein Bike erforderlich")

    url = str(d.get("url", "")).strip()
    if not url.startswith(("http://", "https://")):
        raise ValueError("Display-URL muss mit http:// oder https:// beginnen")

    backend_url = str(a.get("backend_url", "")).strip()
    if not backend_url.startswith(("http://", "https://")):
        raise ValueError("Backend-URL muss mit http:// oder https:// beginnen")

    method = str(a.get("method", "POST")).upper()
    if method not in ("POST", "PUT", "PATCH"):
        raise ValueError("HTTP-Methode muss POST, PUT oder PATCH sein")

    refresh = int(d.get("refresh_interval_sec", 30))
    interval = int(a.get("send_interval_ms", 1000))
    timeout = int(a.get("timeout_sec", 5))
    if not (1 <= refresh <= 86400):
        raise ValueError("Refresh-Intervall muss 1-86400 Sekunden sein")
    if not (100 <= interval <= 600000):
        raise ValueError("Send-Intervall muss 100-600000 ms sein")
    if not (1 <= timeout <= 60):
        raise ValueError("Timeout muss 1-60 Sekunden sein")

    pins_seen = set()
    ids_seen = set()
    normalized_bikes = []
    for b in bikes:
        bid = int(b["id"])
        pin = int(b["sensor_pin"])
        if bid in ids_seen:
            raise ValueError(f"Doppelte Bike-ID: {bid}")
        if pin in pins_seen:
            raise ValueError(f"Doppelter GPIO-Pin: {pin}")
        if not (0 <= pin <= 40):
            raise ValueError(f"Ungültiger GPIO-Pin: {pin}")
        ids_seen.add(bid)
        pins_seen.add(pin)
        normalized_bikes.append({
            "id": bid,
            "name": str(b["name"]).strip() or f"Fahrrad {bid}",
            "sensor_pin": pin,
            "wheel_circumference_m": round(float(b["wheel_circumference_m"]), 3),
            "enabled": bool(b["enabled"]),
        })

    return {
        "display": {
            "url": url,
            "refresh_interval_sec": refresh,
            "fullscreen": bool(d.get("fullscreen", True)),
        },
        "api": {
            "backend_url": backend_url,
            "send_interval_ms": interval,
            "auth_token": str(a.get("auth_token", "")),
            "method": method,
            "timeout_sec": timeout,
        },
        "bikes": normalized_bikes,
    }


@app.route("/api/config", methods=["GET"])
@login_required
def api_config_get():
    return jsonify(load_config())


@app.route("/api/config", methods=["POST"])
@login_required
def api_config_save():
    try:
        payload = request.get_json(force=True)
        config = _validate_and_normalize(payload)
        save_config(config)
        return jsonify({"ok": True, "config": config})
    except (KeyError, ValueError, TypeError) as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.route("/api/health")
def health():
    return jsonify({"ok": True, "service": "bike-monitor-webapp"})


if __name__ == "__main__":
    # Im Produktivbetrieb über gunicorn oder systemd starten.
    app.run(host="0.0.0.0", port=8080, debug=False)
