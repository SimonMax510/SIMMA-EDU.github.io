"""
Bike Monitor — User-Verwaltung

Nutzung:
    python3 create_user.py add <username>
    python3 create_user.py remove <username>
    python3 create_user.py list

Passwörter werden interaktiv abgefragt und mit werkzeug.security gehasht.
"""
import sys
import json
import getpass
from pathlib import Path
from werkzeug.security import generate_password_hash

USERS_PATH = Path(__file__).resolve().parent / "webapp" / "users.json"


def load_users() -> dict:
    if not USERS_PATH.exists():
        return {}
    return json.loads(USERS_PATH.read_text(encoding="utf-8"))


def save_users(users: dict) -> None:
    USERS_PATH.parent.mkdir(parents=True, exist_ok=True)
    USERS_PATH.write_text(json.dumps(users, indent=2), encoding="utf-8")
    USERS_PATH.chmod(0o600)


def cmd_add(username: str) -> None:
    users = load_users()
    pw1 = getpass.getpass("Passwort: ")
    pw2 = getpass.getpass("Passwort wiederholen: ")
    if pw1 != pw2:
        print("Passwörter stimmen nicht überein.")
        sys.exit(1)
    if len(pw1) < 6:
        print("Passwort muss mindestens 6 Zeichen lang sein.")
        sys.exit(1)
    users[username] = generate_password_hash(pw1)
    save_users(users)
    print(f"User '{username}' gespeichert.")


def cmd_remove(username: str) -> None:
    users = load_users()
    if username not in users:
        print(f"User '{username}' existiert nicht.")
        sys.exit(1)
    del users[username]
    save_users(users)
    print(f"User '{username}' entfernt.")


def cmd_list() -> None:
    users = load_users()
    if not users:
        print("Keine User angelegt.")
        return
    for name in users:
        print(f"- {name}")


def main() -> None:
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    cmd = sys.argv[1]
    if cmd == "add" and len(sys.argv) == 3:
        cmd_add(sys.argv[2])
    elif cmd == "remove" and len(sys.argv) == 3:
        cmd_remove(sys.argv[2])
    elif cmd == "list":
        cmd_list()
    else:
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
