# Bike Monitor — Web Adminpanel

Login-geschütztes Webinterface zum Bearbeiten einer `config.json`.
Die JSON-Datei kann später vom Pi-Programm gelesen werden, um zu wissen,
welche Webseite anzuzeigen ist und wohin Sensordaten geschickt werden.

## Was die Webapp macht

1. Login mit gehashtem Passwort
2. Dashboard-Formular für drei Bereiche:
   - **Anzeige**: welche URL der Beamer zeigt + Refresh-Intervall + Vollbild
   - **API**: Backend-URL, HTTP-Methode, Sende-Intervall, Auth-Token, Timeout
   - **Fahrräder**: pro Bike ein Name, GPIO-Pin, Radumfang, aktiv-Flag
3. Beim Speichern → schreibt atomar `config.json` (über tmp-Datei + rename, sodass nie eine halb geschriebene Datei gelesen wird)
4. Validierung (URL-Format, Pin-Bereich, Duplikate, Intervall-Grenzen) → bei Fehler HTTP 400 mit Fehlermeldung

## Setup

```bash
# venv anlegen + Dependencies
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate   # Windows
pip install -r requirements.txt

# Ersten User anlegen
python create_user.py add admin

# Webapp starten
python webapp/app.py
```

Dann im Browser: **http://localhost:8080**

## User-Verwaltung

```bash
python create_user.py add <username>      # User anlegen
python create_user.py remove <username>   # User löschen
python create_user.py list                # User auflisten
```

Passwörter werden mit `werkzeug.security.generate_password_hash` (PBKDF2)
gehasht in `webapp/users.json` gespeichert.

## Beispiel der gespeicherten config.json

```json
{
  "display": {
    "url": "https://example.com",
    "refresh_interval_sec": 30,
    "fullscreen": true
  },
  "api": {
    "backend_url": "https://backend.example.com/ingest",
    "send_interval_ms": 1000,
    "auth_token": "",
    "method": "POST",
    "timeout_sec": 5
  },
  "bikes": [
    { "id": 1, "name": "Fahrrad 1", "sensor_pin": 17, "wheel_circumference_m": 2.1, "enabled": true },
    { "id": 2, "name": "Fahrrad 2", "sensor_pin": 18, "wheel_circumference_m": 2.1, "enabled": true },
    { "id": 3, "name": "Fahrrad 3", "sensor_pin": 22, "wheel_circumference_m": 2.1, "enabled": true },
    { "id": 4, "name": "Fahrrad 4", "sensor_pin": 23, "wheel_circumference_m": 2.1, "enabled": true }
  ]
}
```

## Dateibaum

```
bike-monitor/
├── config.json              # wird von der Webapp geschrieben
├── create_user.py           # CLI für User-Verwaltung
├── requirements.txt
├── README.md
└── webapp/
    ├── app.py               # Flask: Login, Dashboard, Save-API
    ├── users.json           # gehashte Passwörter (von create_user.py erzeugt)
    ├── templates/
    │   ├── base.html
    │   ├── login.html
    │   └── dashboard.html
    └── static/
        └── style.css
```

## Endpoints

| Route          | Methode | Auth   | Zweck                             |
|----------------|---------|--------|-----------------------------------|
| `/login`       | GET/POST| -      | Login-Formular                    |
| `/logout`      | GET     | -      | Session löschen                   |
| `/`            | GET     | Login  | Dashboard mit Config-Formular     |
| `/api/config`  | GET     | Login  | Aktuelle Config als JSON          |
| `/api/config`  | POST    | Login  | Neue Config validieren + speichern|
| `/api/health`  | GET     | -      | Healthcheck                       |
